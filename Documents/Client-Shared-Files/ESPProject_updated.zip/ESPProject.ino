

// partition scheme:  minimal spiffs ( 1.9 MB app with OTA, 190 kB spiffs )

// OTA is over 192.168.4.1/firmware


// ALL PINS



const byte resetPin1 = 5,            // RFID Container
           chipSelectPin1 = 21,

           resetPin2 = 2,            // RFID Tray
           chipSelectPin2 = 15,

           stepPin = 16,             // stepper motor driver
           enablePin = 4,
           directionPin = 22,

           servoPin = 27,           // servo motor

           dout = 32,               // HX711
           sck  = 33,

           addressableLED = 26,   // WS2812B

           nextionRX = 17,       // Nextion Screen
           nextionTX = 16,

           none = 89;  // ignore this one


// ESP in AP mode

const char* ssidAP = "AdvancedProject";
const char* passAP = "ELECTRICAL";

const int ledNum = 60;  // 60 LEDs per meter for WS2812B addressable

#define NEXTION_BAUD   115200

// NOT NEEDED FOR NOW

byte channelNo = 3 ,  // range:1-14 INCLUSIVE
     ssidHide = 0 ,
     maxClients = 8;

// CONSTANTS

const bool clockWise = true,
           counterClockWise = ! clockWise;

// HEADERS

#include "RFIDHeader.h"
#include "OTAHeader.h"
#include "nextionHeader.h"
#include "servoHeader.h"
#include "LEDHeader.h"
#include "loadCellHeader.h"



// MAIN PROGRAM

void setup() {
  Serial.begin(115200);
  Serial.println("\n\nBooting...");

  Serial.println("initPins...");
  initPins();
  Serial.println("initReader...");
  initReader();
  Serial.println("initNextion...");
  initNextion();
  Serial.println("initLED...");
  initLED();
  Serial.println("initLoadCell...");
  initLoadCell();
  Serial.println("initWiFiAP...");
  initWiFiAP();
  Serial.println("\nAll Init'd...");

}

// servoRun(100, 0);
// if readCard(mfrc522Container).length() > 5
// readWeight()   // in grams
// handleWiFiClients()

void loop() {
handleWiFiClients();
}


void initPins() {
  pinMode(stepPin, OUTPUT);
  pinMode(enablePin, OUTPUT);
  pinMode(directionPin, OUTPUT);

  digitalWrite(enablePin, HIGH);  // stepper motor off on start up
}
